
package parcialmedico;


public class Turno {
    Consulta [] consulta;

    public Turno(int cantidad) {
        this.consulta= new Consulta[cantidad];
    }
    
    public void agregarConsulta(Consulta c){
        for (int i = 0; i < consulta.length; i++) {
            if (consulta[i]== null) {
               consulta[i]=c;
               break;
            }
        }
    }
    
    
    public int cantImp0(){
        int cantidad = 0;
        for (int i = 0; i < consulta.length; i++) {
            if(consulta[i]!= null && consulta[i].getImporte()== 0){
                cantidad++;
            
            }
        }
        return cantidad;
    }
    
    
    public String nomPaciente(int num){
        String nombre="";
        for (int i = 0; i < consulta.length; i++) {
            if (consulta[i]!=null && consulta[i].getnumHistCli()==num) {
                nombre= consulta[i].getNombrePaciente();
            }
        }
        return nombre;
    
    }
    
    
    public double promedio(){
        double prom=0;
        int contador=0;
        int acumulador=0;
        for (int i = 0; i < consulta.length; i++) {
            if (consulta[i]!= null && consulta[i].getImporte()!=0) {
                acumulador += consulta[i].getImporte();
                contador++;
                prom= acumulador/contador;
            }
        }
        
        return prom;
    }
    
    
   
    
    

   

}

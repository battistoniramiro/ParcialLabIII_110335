
package parcialmedico;

import java.util.Scanner;

public class ParcialMedico {

   
    public static void main(String[] args) {
        Scanner sc= new Scanner(System.in);
        System.out.println("ingrese cantidad de consultas: ");
        int cant= sc.nextInt();
        
        Turno t= new Turno(cant);
        
        for (int i = 0; i < cant; i++) {
            System.out.println("Por favor ingrese numero de historia clinica: ");
            int num=sc.nextInt();
            sc.nextLine();
            System.out.println("Por favor ingrese nombre del paciente: ");
            String nombre= sc.nextLine();
            System.out.println("Por favor ingrese importe a cobrar: ");
            double imp=sc.nextDouble();
            Consulta c= new Consulta(num,nombre,imp);
            t.agregarConsulta(c);
        }
        
        System.out.println("Cantidad de consultas importe 0: "+ t.cantImp0());
        System.out.println("ingrese numero de historia clinica del paciente: ");
        int numero=sc.nextInt();
        System.out.println("el nombre del paciente es: "+t.nomPaciente(numero));
        
        
    }
    
}


package parcialmedico;


public class Consulta {
    private int numHistCli;
    private String nombrePaciente;
    private double importe;
    
    

    public Consulta(int numHistroriaClinica, String nombrePaciente, double importe) {
        this.numHistCli = numHistroriaClinica;
        this.nombrePaciente = nombrePaciente;
        this.importe = importe;
        
        
        
    }

    public int getnumHistCli() {
        return numHistCli;
    }

    public void setnumHistCli(int numHistroriaClinica) {
        this.numHistCli = numHistroriaClinica;
    }

    public String getNombrePaciente() {
        return nombrePaciente;
    }

    public void setNombrePaciente(String nombrePaciente) {
        this.nombrePaciente = nombrePaciente;
    }

    public double getImporte() {
        return importe;
    }

    public void setImporte(double importe) {
        this.importe = importe;
    }



    
    
    
}
